#pragma once
#include <glm/gtx/transform.hpp>

class SceneManager;

class Prefabs
{
public:
	// object prefabs
	static void DrawChair(SceneManager& scene, const glm::vec3& position, const glm::vec3& rotation);

	static void DrawTable(SceneManager& scene, const glm::vec3& positition, const glm::vec3& rotation);

	static void DrawLongChair(SceneManager& scene, const glm::vec3& position, const glm::vec3& rotation);

	static void DrawLongTable(SceneManager& scene, const glm::vec3& position, const glm::vec3& rotation);

	static void DrawPillar(SceneManager& scene, const glm::vec3& position, const glm::vec3& rotation);

	static void DrawArchway(SceneManager& scene, const glm::vec3& position, const glm::vec3& rotation);

	// object group prefabs
	static void DrawTableSet(SceneManager& scene, const glm::vec3& position, float YrotationDegrees);

	static void DrawLongTableSet(SceneManager& scene, const glm::vec3& position, float YrotationDegrees);

	static void DrawStructure(SceneManager& scene, const glm::vec3 & postiion, float YrotationDegrees);
};