// Prefabs.cpp
#include "Prefabs.h"
#include "SceneManager.h"
#include <glm/gtx/transform.hpp>

using glm::vec3;
 
// Rotate a local offset relative to some anchor
static vec3 RotateOffset(const vec3& localOffset, const vec3& rotationDeg)
{
    glm::mat4 R(1.0f);
    R = glm::rotate(glm::radians(rotationDeg.x), vec3(1, 0, 0)) * R;
    R = glm::rotate(glm::radians(rotationDeg.y), vec3(0, 1, 0)) * R;
    R = glm::rotate(glm::radians(rotationDeg.z), vec3(0, 0, 1)) * R;

    glm::vec4 rotated = R * glm::vec4(localOffset, 1.0f);
    return vec3(rotated);
}


//********************************** PREFAB OBJECTS ****************************************************\\

// chair prefab
void Prefabs::DrawChair( SceneManager& scene, const vec3& position, const vec3& rotation)
{
    auto* meshes = scene.GetMeshes();

    vec3 scaleXYZ;
    vec3 rot = rotation;

    // anchor point, for rotating the chair around
    const vec3 anchorLocal(0.0f, 2.0f, 4.0f);

    // Convert a local coordinate to world space
    auto worldPos = [&](const vec3& local)
        {
            // move so anchor is at origin
            vec3 fromAnchor = local - anchorLocal;    

            // rotate around anchor
            vec3 rotated = RotateOffset(fromAnchor, rot);  
            return position + rotated;
        };

    // Seat
    scaleXYZ = vec3(1.5f, 0.2f, 1.5f);
    scene.SetTransformations(
        scaleXYZ,
        rot.x, rot.y, rot.z,
        worldPos(vec3(0.0f, 2.0f, 4.0f)));

    scene.SetTextureUVScale(1.0f, 1.0f);
    scene.SetShaderTexture("Bread_crust");
    scene.SetShaderMaterial("wood");
    meshes->DrawBoxMesh();

    // Legs
    scaleXYZ = vec3(0.2f, 2.0f, 0.2f);

    // front-left
    scene.SetTransformations(
        scaleXYZ, rot.x, rot.y, rot.z,
        worldPos(vec3(-0.7f, 1.0f, 4.7f)));
    scene.SetTextureUVScale(1.0f, 1.0f);
    scene.SetShaderTexture("wood_box");
    meshes->DrawBoxMesh();

    // front-right
    scene.SetTransformations(
        scaleXYZ, rot.x, rot.y, rot.z,
        worldPos(vec3(0.7f, 1.0f, 4.7f)));
    scene.SetTextureUVScale(1.0f, 1.0f);
    scene.SetShaderTexture("wood_box");
    meshes->DrawBoxMesh();

    // back-left
    scene.SetTransformations(
        scaleXYZ, rot.x, rot.y, rot.z,
        worldPos(vec3(-0.7f, 1.0f, 3.3f)));
    scene.SetTextureUVScale(1.0f, 1.0f);
    scene.SetShaderTexture("wood_box");
    meshes->DrawBoxMesh();

    // back-right
    scene.SetTransformations(
        scaleXYZ, rot.x, rot.y, rot.z,
        worldPos(vec3(0.7f, 1.0f, 3.3f)));
    scene.SetTextureUVScale(1.0f, 1.0f);
    scene.SetShaderTexture("wood_box");
    meshes->DrawBoxMesh();

    // Back vertical rails
    scaleXYZ = vec3(0.2f, 2.5f, 0.1f);

    // left rail
    scene.SetTransformations(
        scaleXYZ, rot.x, rot.y, rot.z,
        worldPos(vec3(-0.7f, 3.25f, 3.2f)));
    scene.SetTextureUVScale(1.0f, 1.0f);
    scene.SetShaderTexture("wood_box");
    meshes->DrawBoxMesh();

    // right rail
    scene.SetTransformations(
        scaleXYZ, rot.x, rot.y, rot.z,
        worldPos(vec3(0.7f, 3.25f, 3.2f)));
    scene.SetTextureUVScale(1.0f, 1.0f);
    scene.SetShaderTexture("wood_box");
    meshes->DrawBoxMesh();

    // Back horizontal bars
    scaleXYZ = vec3(1.5f, 0.5f, 0.07f);

    // top bar
    scene.SetTransformations(
        scaleXYZ, rot.x, rot.y, rot.z,
        worldPos(vec3(0.0f, 4.0f, 3.2f)));
    scene.SetTextureUVScale(1.0f, 1.0f);
    scene.SetShaderTexture("wood_box");
    meshes->DrawBoxMesh();

    // middle bar
    scene.SetTransformations(
        scaleXYZ, rot.x, rot.y, rot.z,
        worldPos(vec3(0.0f, 3.0f, 3.2f)));
    scene.SetTextureUVScale(1.0f, 1.0f);
    scene.SetShaderTexture("wood_box");
    meshes->DrawBoxMesh();
}

// table prefab
void Prefabs::DrawTable(SceneManager& scene, const vec3& position, const vec3& rotation)
{
    auto* meshes = scene.GetMeshes();

    vec3 scaleXYZ;
    vec3 rot = rotation;

    // top center pivot
    const vec3 anchorLocal(0.0f, 3.0f, 0.0f);

    auto worldPos = [&](const vec3& local)
        {
            vec3 fromAnchor = local - anchorLocal;
            vec3 rotated = RotateOffset(fromAnchor, rot);
            return position + rotated;
        };

    // Table top
    scaleXYZ = vec3(4.0f, 0.2f, 4.0f);
    scene.SetTransformations(
        scaleXYZ,
        rot.x, rot.y, rot.z,
        worldPos(vec3(0.0f, 3.0f, 0.0f)));

    scene.SetTextureUVScale(1.0f, 1.0f);
    scene.SetShaderTexture("wood_box");
    scene.SetShaderMaterial("wood");
    meshes->DrawBoxMesh();

    // Legs 
    scaleXYZ = vec3(0.3f, 3.0f, 0.3f);

    scene.SetTransformations(
        scaleXYZ, rot.x, rot.y, rot.z,
        worldPos(vec3(0.0f, 1.5f, 0.0f)));
    meshes->DrawBoxMesh();

}

// long chair prefab (bench style)
void Prefabs::DrawLongChair(SceneManager& scene, const vec3& position, const vec3& rotation)
{
    auto* meshes = scene.GetMeshes();

    vec3 scaleXYZ;
    vec3 rot = rotation;

    // anchor point, for rotating the long chair around (seat center)
    const vec3 anchorLocal(0.0f, 2.0f, 0.0f);

    // Convert a local coordinate to world space
    auto worldPos = [&](const vec3& local)
        {
            vec3 fromAnchor = local - anchorLocal;
            vec3 rotated = RotateOffset(fromAnchor, rot);
            return position + rotated;
        };

    //******************************** Long chair seat ********************************\\

    scaleXYZ = vec3(9.0f, 0.25f, 1.5f);

    scene.SetTransformations(
        scaleXYZ,
        rot.x, rot.y, rot.z,
        worldPos(vec3(0.0f, 2.0f, 0.0f)));

    scene.SetTextureUVScale(1.0f, 1.0f);
    scene.SetShaderTexture("Bread_crust");
    scene.SetShaderMaterial("wood");
    meshes->DrawBoxMesh();

    //******************************** Long chair back ********************************\\

    scaleXYZ = vec3(9.0f, 1.5f, 0.25f);

    scene.SetTransformations(
        scaleXYZ,
        rot.x, rot.y, rot.z,
        worldPos(vec3(0.0f, 3.0f, -0.7f)));

    scene.SetTextureUVScale(1.0f, 1.0f);
    scene.SetShaderTexture("wood_box");
    meshes->DrawBoxMesh();

    //******************************** Long chair legs ********************************\\
    // front leg scale
    scaleXYZ = vec3(0.25f, 2.0f, 0.25f);

    // front left
    scene.SetTransformations(
        scaleXYZ, rot.x, rot.y, rot.z,
        worldPos(vec3(-4.2f, 1.0f, 0.65f)));
    scene.SetTextureUVScale(1.0f, 1.0f);
    scene.SetShaderTexture("wood_box");
    meshes->DrawBoxMesh();

    // front right
    scene.SetTransformations(
        scaleXYZ, rot.x, rot.y, rot.z,
        worldPos(vec3(4.2f, 1.0f, 0.65f)));
    meshes->DrawBoxMesh();

    // back legs scale
    scaleXYZ = vec3(0.25f, 3.6f, 0.25f);

    // back left
    scene.SetTransformations(
        scaleXYZ, rot.x, rot.y, rot.z,
        worldPos(vec3(-4.2f, 1.75f, -0.85f)));
    meshes->DrawBoxMesh();

    // back right
    scene.SetTransformations(
        scaleXYZ, rot.x, rot.y, rot.z,
        worldPos(vec3(4.2f, 1.75f, -0.85f)));
    meshes->DrawBoxMesh();

    // back middle
    scene.SetTransformations(
        scaleXYZ, rot.x, rot.y, rot.z,
        worldPos(vec3(0.0f, 1.75f, -0.85f)));
    meshes->DrawBoxMesh();
}

// long table prefab
void Prefabs::DrawLongTable(SceneManager& scene, const vec3& position, const vec3& rotation)
{
    auto* meshes = scene.GetMeshes();

    vec3 scaleXYZ;
    vec3 rot = rotation;

    // top center pivot
    const vec3 anchorLocal(0.0f, 3.0f, 0.0f);

    auto worldPos = [&](const vec3& local)
        {
            vec3 fromAnchor = local - anchorLocal;
            vec3 rotated = RotateOffset(fromAnchor, rot);
            return position + rotated;
        };

    //******************************** Long table top ********************************\\

    scaleXYZ = vec3(10.0f, 0.2f, 3.5f);

    scene.SetTransformations(
        scaleXYZ,
        rot.x, rot.y, rot.z,
        worldPos(vec3(0.0f, 3.0f, 0.0f)));

    scene.SetTextureUVScale(1.0f, 1.0f);
    scene.SetShaderTexture("wood_box");
    scene.SetShaderMaterial("wood");
    meshes->DrawBoxMesh();

    //******************************** Long table legs ********************************\\

    scaleXYZ = vec3(0.35f, 3.0f, 0.35f);

    // left leg
    scene.SetTransformations(
        scaleXYZ, rot.x, rot.y, rot.z,
        worldPos(vec3(-4.5f, 1.5f, 0.0f)));
    meshes->DrawBoxMesh();

    // right leg
    scene.SetTransformations(
        scaleXYZ, rot.x, rot.y, rot.z,
        worldPos(vec3(4.5f, 1.5f, 0.0f)));
    meshes->DrawBoxMesh();
}

// pillar prefab
void Prefabs::DrawPillar(SceneManager& scene, const vec3& position, const vec3& rotation)
{
    auto* meshes = scene.GetMeshes();

    vec3 scaleXYZ;
    vec3 rot = rotation;

    // anchor point, for rotating the pillar around (base center)
    const vec3 anchorLocal(0.0f, 0.0f, 0.0f);

    // Convert a local coordinate to world space
    auto worldPos = [&](const vec3& local)
        {
            // move so anchor is at origin
            vec3 fromAnchor = local - anchorLocal;

            // rotate around anchor
            vec3 rotated = RotateOffset(fromAnchor, rot);
            return position + rotated;
        };

    //******************************** Pillar base ********************************\\
	// short, wider cylinder at the bottom
    scaleXYZ = vec3(0.5f, 3.0f, 0.5f);

    scene.SetTransformations(
        scaleXYZ,
        rot.x, rot.y, rot.z,
        worldPos(vec3(0.0f, 0.0f, 0.0f)));

    // placeholder stone color
    scene.SetShaderColor(0.75f, 0.75f, 0.75f, 1.0f);
    scene.SetShaderMaterial("cement");

    // draw
    meshes->DrawCylinderMesh();

    //******************************** Pillar shaft *******************************\\
	// tall cylinder
    scaleXYZ = vec3(0.3f, 20.0f, 0.3f);

    scene.SetTransformations(
        scaleXYZ,
        rot.x, rot.y, rot.z,
        worldPos(vec3(0.0f, 3.0f, 0.0f)));

    scene.SetShaderColor(0.82f, 0.82f, 0.82f, 1.0f);
    scene.SetShaderMaterial("cement");

    // draw
    meshes->DrawCylinderMesh();
}

// archway prefab
void Prefabs::DrawArchway(SceneManager& scene, const vec3& position, const vec3& rotation)
{
    auto* meshes = scene.GetMeshes();

    vec3 scaleXYZ;
    vec3 rot = rotation;

    // anchor point, for rotating the archway around (bottom center)
    const vec3 anchorLocal(0.0f, 0.0f, 0.0f);

    // Convert a local coordinate to world space
    auto worldPos = [&](const vec3& local)
        {
            vec3 fromAnchor = local - anchorLocal;
            vec3 rotated = RotateOffset(fromAnchor, rot);
            return position + rotated;
        };

    // placeholder stone color
    scene.SetShaderColor(0.78f, 0.78f, 0.78f, 1.0f);
    scene.SetShaderMaterial("cement");

    // basic sizing
    const float doorWidth = 6.0f;
    const float doorHeight = 10.0f;
    const float thickness = 1.0f;

    //********************************** Side posts *******************************\\

    scaleXYZ = vec3(1.0f, doorHeight, thickness);

    // left post
    scene.SetTransformations(
        scaleXYZ,
        rot.x, rot.y, rot.z,
        worldPos(vec3(-(doorWidth * 0.5f), doorHeight * 0.5f, 0.0f)));
    meshes->DrawBoxMesh();

    // right post
    scene.SetTransformations(
        scaleXYZ,
        rot.x, rot.y, rot.z,
        worldPos(vec3((doorWidth * 0.5f), doorHeight * 0.5f, 0.0f)));
    meshes->DrawBoxMesh();

    //********************************** First angled blocks **********************\\
    // two shorter rectangles above them at a rotation
    const float firstAngle = 60.0f;
    const float firstY = doorHeight + 0.6f;

    scaleXYZ = vec3(3.0f, 1.0f, thickness);

    // left angled
    scene.SetTransformations(
        scaleXYZ,
        rot.x, rot.y, rot.z + firstAngle,
        worldPos(vec3(-(doorWidth * 0.4f), firstY, 0.0f)));
    meshes->DrawBoxMesh();

    // right angled (mirror angle)
    scene.SetTransformations(
        scaleXYZ,
        rot.x, rot.y, rot.z - firstAngle,
        worldPos(vec3((doorWidth * 0.4f), firstY, 0.0f)));
    meshes->DrawBoxMesh();

    //********************************** Second angled blocks *********************\\
    // two more shorter rectangles above them with more rotation
    const float secondAngle = 25.0f;
    const float secondY = doorHeight + 2.0f;

    scaleXYZ = vec3(2.2f, 1.0f, thickness);

    // left angled
    scene.SetTransformations(
        scaleXYZ,
        rot.x, rot.y, rot.z + secondAngle,
        worldPos(vec3(-(doorWidth * 0.15f), secondY, 0.0f)));
    meshes->DrawBoxMesh();

    // right angled
    scene.SetTransformations(
        scaleXYZ,
        rot.x, rot.y, rot.z - secondAngle,
        worldPos(vec3((doorWidth * 0.15f), secondY, 0.0f)));
    meshes->DrawBoxMesh();

    //********************************** Door box *******************************\\

    scene.SetShaderColor(0.25f, 0.25f, 0.25f, 1.0f);
    scene.SetShaderMaterial("cement");

    // width, height, thickness
    scaleXYZ = vec3(5.0f, 12.0f, 0.05f);

    scene.SetTransformations(
        scaleXYZ,
        rot.x, rot.y, rot.z,
        worldPos(vec3(0.0f, 6.0f, 0.0f)));

    meshes->DrawBoxMesh();
}



//************************************ PREFAB GROUPS ****************************************************\\
// table set prefab
void Prefabs::DrawTableSet(SceneManager& scene, const vec3& position, float YrotationDegrees)
{
    //******************************* Table *********************************************\\

    Prefabs::DrawTable(
        scene,
        position,
        vec3(0.0f, YrotationDegrees, 0.0f));

    // distance from table center to each chair
    const float chairDistance = 2.5f;

    // chair seat pivot height is lower than table top pivot
    const float chairSeatY = 2.0f;

    // build rotation vector once
    vec3 setRotation(0.0f, YrotationDegrees, 0.0f);

    // helper to rotate chair offsets around the table center
    auto rotatedPosition = [&](const vec3& localOffset)
        {
            return position + RotateOffset(localOffset, setRotation);
        };

    //******************************** Chairs ******************************************\\

    // front chair
    Prefabs::DrawChair(
        scene,
        rotatedPosition(vec3(0.0f, chairSeatY - position.y, -chairDistance)),
        vec3(0.0f, YrotationDegrees + 0.0f, 0.0f));

    // back chair
    Prefabs::DrawChair(
        scene,
        rotatedPosition(vec3(0.0f, chairSeatY - position.y, chairDistance)),
        vec3(0.0f, YrotationDegrees + 180.0f, 0.0f));

    // left chair
    Prefabs::DrawChair(
        scene,
        rotatedPosition(vec3(-chairDistance, chairSeatY - position.y, 0.0f)),
        vec3(0.0f, YrotationDegrees + 90.0f, 0.0f));

    // right chair
    Prefabs::DrawChair(
        scene,
        rotatedPosition(vec3(chairDistance, chairSeatY - position.y, 0.0f)),
        vec3(0.0f, YrotationDegrees + 270.0f, 0.0f));
}


// long table set prefab
void Prefabs::DrawLongTableSet(SceneManager& scene, const vec3& position, float YrotationDegrees)
{
    //******************************* Long table ****************************************\\

    Prefabs::DrawLongTable(
        scene,
        position,
        vec3(0.0f, YrotationDegrees, 0.0f));

    // build rotation vector once
    vec3 setRotation(0.0f, YrotationDegrees, 0.0f);

    // helper to rotate offsets around the table center
    auto rotatedPosition = [&](const vec3& localOffset)
        {
            return position + RotateOffset(localOffset, setRotation);
        };

    //******************************* Long chairs **************************************\\

    // bench distance from table center
    const float chairDistance = 2.25f;

    // chair seat pivot height (same idea as your normal set)
    const float chairSeatY = 2.0f;

    // left side bench
    Prefabs::DrawLongChair(
        scene,
        rotatedPosition(vec3(0.0f, chairSeatY - position.y, -chairDistance)),
        vec3(0.0f, YrotationDegrees + 0.0f, 0.0f));

    // right side bench (facing opposite)
    Prefabs::DrawLongChair(
        scene,
        rotatedPosition(vec3(0.0f, chairSeatY - position.y, chairDistance)),
        vec3(0.0f, YrotationDegrees + 180.0f, 0.0f));
}

// structure prefab
void Prefabs::DrawStructure(SceneManager& scene, const vec3& position, float YrotationDegrees)
{
    auto* meshes = scene.GetMeshes();

    // build rotation vector once
    vec3 setRotation(0.0f, YrotationDegrees, 0.0f);

    // helper to rotate offsets around the structure center
    auto rotatedPosition = [&](const vec3& localOffset)
        {
            return position + RotateOffset(localOffset, setRotation);
        };

    //********************************** Structure settings ************************\\

    vec3 scaleXYZ;
    vec3 wallColor(0.20f, 0.20f, 0.20f);

    // wall dimensions
    const float wallLength = 20.0f;
    const float wallHeight = 23.0f;
    const float wallThickness = 0.25f;

    // depth of the structure (distance between the two long walls)
    const float boxDepth = 10.0f;

    const float halfLong = wallLength * 0.5f;
    const float halfDepth = boxDepth * 0.5f;

    // spacing used to fake the curved corner with pillars
    const float cornerStep = 0.75f;

    //********************************** Long walls ********************************\\
    // skinny box walls (no planes)
    scaleXYZ = vec3(wallLength, wallHeight, wallThickness);

    scene.SetShaderColor(wallColor.x, wallColor.y, wallColor.z, 1.0f);
    scene.SetShaderMaterial("cement");

    // front long wall (z = -halfDepth)
    scene.SetTransformations(
        scaleXYZ,
        0.0f, YrotationDegrees, 0.0f,
        rotatedPosition(vec3(0.0f, wallHeight * 0.5f, -halfDepth)));
    meshes->DrawBoxMesh();

    // back long wall (z = +halfDepth)
    scene.SetTransformations(
        scaleXYZ,
        0.0f, YrotationDegrees, 0.0f,
        rotatedPosition(vec3(0.0f, wallHeight * 0.5f, halfDepth)));
    meshes->DrawBoxMesh();

    //********************************** Archways ********************************\\

    const float archSpacingX = 5.0f;
    const float archPushOutZ = 0.25f;

    // front wall arches (out is -Z)
    // arch prefab faces +Z by default, so rotate Y +180 to face -Z
    Prefabs::DrawArchway(
        scene,
        rotatedPosition(vec3(-archSpacingX, 0.0f, -halfDepth - archPushOutZ)),
        vec3(0.0f, YrotationDegrees + 180.0f, 0.0f));

    Prefabs::DrawArchway(
        scene,
        rotatedPosition(vec3(archSpacingX, 0.0f, -halfDepth - archPushOutZ)),
        vec3(0.0f, YrotationDegrees + 180.0f, 0.0f));

    // back wall arches (out is +Z)
    Prefabs::DrawArchway(
        scene,
        rotatedPosition(vec3(-archSpacingX, 0.0f, halfDepth + archPushOutZ)),
        vec3(0.0f, YrotationDegrees, 0.0f));

    Prefabs::DrawArchway(
        scene,
        rotatedPosition(vec3(archSpacingX, 0.0f, halfDepth + archPushOutZ)),
        vec3(0.0f, YrotationDegrees, 0.0f));

    //********************************** Draw short side helper *********************\\
    // 6 pillars + short wall + top connector wall (convex outward)
    auto drawShortSide = [&](float xSign)
        {
            // short side sits at x = +-halfLong
            const float shortSideX = xSign * halfLong;

            // outward direction for convex curve
            const float outwardX = xSign * cornerStep;

            //********************************** Corner curve pillars *********************\\
            // for each corner:
            // p0 = true corner at the long wall end
            // p1 = inner curve pillar
            // p2 = outer curve pillar (top connector connects between these)

            // near corner (front wall) at z = -halfDepth, moving toward center is +Z
            vec3 nearP0 = vec3(shortSideX, 0.0f, -halfDepth);
            vec3 nearP1 = vec3(shortSideX + outwardX, 0.0f, -halfDepth + cornerStep);
            vec3 nearP2 = vec3(shortSideX + outwardX * 2.0f, 0.0f, -halfDepth + cornerStep * 2.0f);

            // far corner (back wall) at z = +halfDepth, moving toward center is -Z
            vec3 farP0 = vec3(shortSideX, 0.0f, halfDepth);
            vec3 farP1 = vec3(shortSideX + outwardX, 0.0f, halfDepth - cornerStep);
            vec3 farP2 = vec3(shortSideX + outwardX * 2.0f, 0.0f, halfDepth - cornerStep * 2.0f);

            //********************************** Draw pillars *****************************\\

            Prefabs::DrawPillar(scene, rotatedPosition(nearP0), vec3(0.0f, YrotationDegrees, 0.0f));
            Prefabs::DrawPillar(scene, rotatedPosition(nearP1), vec3(0.0f, YrotationDegrees, 0.0f));
            Prefabs::DrawPillar(scene, rotatedPosition(nearP2), vec3(0.0f, YrotationDegrees, 0.0f));

            Prefabs::DrawPillar(scene, rotatedPosition(farP0), vec3(0.0f, YrotationDegrees, 0.0f));
            Prefabs::DrawPillar(scene, rotatedPosition(farP1), vec3(0.0f, YrotationDegrees, 0.0f));
            Prefabs::DrawPillar(scene, rotatedPosition(farP2), vec3(0.0f, YrotationDegrees, 0.0f));
            
            //********************************** Top connector wall ************************\\
            // top connector connects the outer pillars (nearP2 and farP2)
            vec3 topWallMid = (nearP2 + farP2) * 0.5f;
            float topWallSpan = glm::length(farP2 - nearP2);

            scene.SetShaderColor(wallColor.x, wallColor.y, wallColor.z, 1.0f);
            scene.SetShaderMaterial("cement");

            scene.SetTransformations(
                vec3(topWallSpan, wallHeight, wallThickness),
                0.0f, YrotationDegrees + 90.0f, 0.0f,
                rotatedPosition(vec3(topWallMid.x, wallHeight * 0.5f, topWallMid.z)));

            meshes->DrawBoxMesh();

            //********************************** Corner diagonal walls *********************\\
            // diagonal wall thickness matches walls
            const float diagThickness = wallThickness;

            // diagonal wall length along its long axis
            const float diagSpan = cornerStep * 3.0f;

            vec3 nearDiagMid = (nearP0 + nearP1) * 0.5f;
            vec3 farDiagMid = (farP0 + farP1) * 0.5f;

            // small nudge to center the corner
            const float diagNudge = wallThickness * -1.0f;

            vec3 nearDir = glm::normalize(nearP0 - nearP1);
            vec3 farDir = glm::normalize(farP0 - farP1);

            nearDiagMid += nearDir * diagNudge;
            farDiagMid += farDir * diagNudge;


            // diagonal walls are skinny boxes rotated 45 degrees around Y
            // left side needs opposite diagonal direction from right side
            float diagAngle = (xSign < 0.0f) ? 45.0f : -45.0f;

            // near diagonal
            scene.SetTransformations(
                vec3(diagSpan, wallHeight, diagThickness),
                0.0f, YrotationDegrees + diagAngle, 0.0f,
                rotatedPosition(vec3(nearDiagMid.x, wallHeight * 0.5f, nearDiagMid.z)));

            meshes->DrawBoxMesh();

            // far diagonal
            scene.SetTransformations(
                vec3(diagSpan, wallHeight, diagThickness),
                0.0f, YrotationDegrees - diagAngle, 0.0f,
                rotatedPosition(vec3(farDiagMid.x, wallHeight * 0.5f, farDiagMid.z)));

            meshes->DrawBoxMesh();
            
        };
        

    // call functions for short walls
    drawShortSide(-1.0f);   // left
    drawShortSide(1.0f);    // right
}

